<?php
include ($_SERVER['DOCUMENT_ROOT'] . '/unexponews/config/config.php');
$sql = "SELECT * FROM news";
$query = mysqli_query($link, $sql);
?>