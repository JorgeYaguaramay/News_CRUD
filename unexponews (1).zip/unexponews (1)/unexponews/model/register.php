<?php
require_once ('./config/config.php');

// Define variables and initialize with empty values
$username = $email = $password = "";
$username_err = $email_err = $password_err = "";
// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate username
    if (empty (trim($_POST["username"]))) {
        $username_err = "Por favor ingrese un nombre de usuario.";
    } else {
        // Prepare a select statement
        $sql = "SELECT username, email FROM users WHERE username = ? OR email = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_email);

            // Set parameters
            $param_username = trim($_POST["username"]);
            $param_email = trim($_POST["email"]);

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                /* store result */
                mysqli_stmt_store_result($stmt);
                mysqli_stmt_bind_result($stmt, $username_db, $email_db);

                if (mysqli_stmt_fetch($stmt)) {
                    if ($username_db == $param_username) {
                        $username_err = "Este nombre de usuario ya está siendo utilizado.";
                    }
                    if ($email_db == $param_email) {
                        $email_err = "Este correo electrónico ya está siendo utilizado.";
                    }
                } else {
                    $username = trim($_POST["username"]);
                    $email = trim($_POST["email"]);
                }
            } else {
                echo "Al parecer algo salió mal.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Validate password
    if (empty (trim($_POST["password"]))) {
        $password_err = "Por favor ingresa una contraseña.";
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "La contraseña al menos debe tener 6 caracteres.";
    } else {
        $password = trim($_POST["password"]);

        // Validate username data
        if (empty (trim($_POST["username"]))) {
            $username_err = "Debes colocar tu nombre de usuario.";
        } else {
            $username = trim($_POST["username"]);
        }
        if (empty (trim($_POST["email"]))) {
            $email_err = "Debes colocar tu correo electrónico.";
        } else {
            $email = trim($_POST["email"]);
        }
    }

    // Check input errors before inserting in database
    if (empty ($username_err) && empty ($email_err) && empty ($password_err)) {

        // Prepare an insert statement
        $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";

        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sss", $param_username, $param_email, $param_password);

            // Set parameters
            $param_username = $username;
            $param_email = $email;
            $param_password = $password;

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                // Redirect to login page
                header("location: ./login.php");
            } else {
                header("location: ./register.php");
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>