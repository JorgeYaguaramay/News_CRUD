<?php
include($_SERVER['DOCUMENT_ROOT'] . '/unexponews/config/config.php');
$id = $_GET['id'];
$sql = "SELECT * FROM news WHERE id='$id'";
$query = mysqli_query($link, $sql);
$row = mysqli_fetch_array($query);

$start_date = $row['date'];
// Convierte la fecha a un objeto DateTime
$date_object = new DateTime($start_date);
// Formatea la fecha en el formato 'Y-m-d'
$formatted_date = $date_object->format('Y-m-d');
?>