<?php
include($_SERVER['DOCUMENT_ROOT'] . '/unexponews/config/config.php');
$id = $_GET['id'];
$sql = "SELECT * FROM news WHERE id='$id'";
$query = mysqli_query($link, $sql);
$row = mysqli_fetch_array($query);

$username = $row['author'];

$sql2 = "SELECT * FROM users WHERE username='$username'";
$query2 = mysqli_query($link, $sql2);
$row2 = mysqli_fetch_array($query2);

?>