<?php
require ($_SERVER['DOCUMENT_ROOT'] . '/unexponews/config/config.php');
$author = $_POST['author'];
$date = $_POST['date'];
$title = $_POST['title'];
$text = $_POST['text'];
$id = $_POST['id'];

$sql = "UPDATE news SET author='$author', date='$date', title='$title', text='$text' WHERE id='$id'";

$query = mysqli_query($link, $sql);

if ($query) {
    header('Location: ../news.php');
    exit();
}
?>