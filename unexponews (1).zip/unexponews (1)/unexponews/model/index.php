<?php
require ($_SERVER['DOCUMENT_ROOT'] . '/unexponews/config/config.php');
$author = $_POST['author'];
$date = $_POST['date'];
$title = $_POST['title'];
$text = $_POST['text'];

$sql = "INSERT INTO news (author, date, text, title) VALUES 
('$author','$date','$text','$title')";

$query = mysqli_query($link, $sql);

if ($query) {
    header('Location: ../news.php');
    exit();
}
?>