<?php
require ($_SERVER['DOCUMENT_ROOT'] . '/unexponews/config/config.php');
$id = $_POST['id'];

$sql = "DELETE FROM news WHERE id='$id'";
$query = mysqli_query($link, $sql);

if ($query) {
    header("Location: ../news.php");
}
?>