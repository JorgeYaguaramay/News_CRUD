<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>UNEXPO Wars | Iniciar sesión</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Registration Start -->
    <div class="container-fluid bg-registration py-5" style="margin: 90px 0;">
        <div class="container py-5">
            <div class="row align-items-center">
                <div class="col-lg-7 mb-5 mb-lg-0">
                    <div class="mb-4">
                        <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">UNEXPO News</h6>
                        <h1 class="text-white"><span class="text-primary">Área de</span> usuarios</h1>
                    </div>
                    <p class="text-white">¡Unete y forma parte del equipo de periodismo de la Universidad Nacional
                        Experimental Politécnica de Venezuela! ¡La verdad y la información es nuestra misión!</p>
                    <ul class="list-inline text-white m-0">
                        <li class="py-2"><i class="fa fa-check text-primary mr-3"></i>Confiabilidad y veracidad
                        </li>
                        <li class="py-2"><i class="fa fa-check text-primary mr-3"></i>Calidad y profesionalidad</li>
                        <li class="py-2"><i class="fa fa-check text-primary mr-3"></i>Estudio e investigación
                        </li>
                    </ul>
                </div>
                <div class="col-lg-5">
                    <div class="card border-0">
                        <div class="card-header bg-primary text-center p-4">
                            <h1 class="text-white m-0">Iniciar sesión</h1>
                        </div>
                        <div class="card-body rounded-bottom bg-white p-5">
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                                    <input type="text" class="form-control p-4" name="username" placeholder="Usuario"
                                        required="required" />
                                        <p class="help-block text-danger"><?php echo $username_err; ?></p>
                                </div>
                                <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                                    <input type="password" class="form-control p-4" name="password" placeholder="Contraseña"
                                        required="required" />
                                        <p class="help-block text-danger"><?php echo $password_err; ?></p>
                                </div>
                                <div class="form-group">
                                    <table class="form-group fullsizetd">
                                        <tbody>
                                            <tr>
                                                <td colspan="2"><button class="btn btn-primary btn-block py-3 fullsizetd"
                                                        type="submit">Iniciar sesión</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="index.php" class="btn btn-info py-3 fullsizetd">Volver al inicio</a></td>
                                                <td><a href="register.php" class="btn btn-success py-3 fullsizetd">Crear cuenta</a></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Registration End -->

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>