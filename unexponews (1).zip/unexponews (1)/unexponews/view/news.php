<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>UNEXPO News | Noticias</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <?php include ("./layouts/header.php") ?>
    <!-- Navbar End -->
    <div class="container-fluid page-header">
        <div class="container">
            <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 400px">
                <h3 class="display-4 text-white text-uppercase">Nuestras noticias</h3>
                <div class="d-inline-flex text-white">
                    <p class="m-0 text-uppercase"><a class="text-white" href="">Inicio</a></p>
                    <i class="fa fa-angle-double-right pt-1 px-3"></i>
                    <p class="m-0 text-uppercase">Noticias</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->


    <!-- Booking Start -->
    <!-- Booking End -->


    <!-- Packages Start -->
    <div class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <div class="text-center mb-3 pb-3">
                <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">Noticias</h6>
                <h1>Leer lista de noticias</h1>
            </div>

            <div class="row">
                <?php
                while ($row = mysqli_fetch_array($query)) {
                    ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="package-item bg-white mb-2">
                            <div class="p-4">
                                <div class="d-flex justify-content-between mb-3">
                                    <small class="m-0"><i
                                            class="fa fa-calendar-alt text-primary mr-2"></i><?php echo $row['date'] ?></small>
                                    <small class="m-0"><i
                                            class="fa fa-user text-primary mr-2"></i><?php echo $row['author'] ?></small>
                                </div>
                                <a class="h5 text-decoration-none" href="read.php?id=<?php echo $row['id'] ?>"><?php echo $row['title'] ?></a></br>
                                <div class="border-top mt-4 pt-4">
                                    <div class="d-flex justify-content-between">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h6 class="m-0"><i class="fa fa-star text-primary mr-2"></i>5
                                                            <small>(UNEXPO)</small>
                                                        </h6>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) { ?>
                                                        <td class="text-center"><a
                                                                href="editnews.php?id=<?php echo $row['id'] ?>"
                                                                class="btn btn-info">Modificar</a>
                                                        </td>
                                                        <td><form method="post" action="./model/delete.php">
                                                        <input type="hidden" name="id" value="<?php echo $row['id'] ?>"/>
                                                        <input type="submit" value="Borrar" class="btn btn-danger">
                                                    </form></td>
                                                        <?php
                                                        }
                                                        ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
    <!-- Packages End -->


    <!-- Destination Start -->

    <!-- Destination Start -->


    <!-- Footer Start -->
    <?php include ("./layouts/footer.php") ?>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>