<?php

$url = 'login';

if (!empty($_GET['url'])) {
    $url = $_GET['url'];
}

if (is_file("./controller/" . $url . ".php")) {
    require_once("./controller/" . $url . ".php");
} else {
    echo 'Pagina en construccion';
}


?>