<?php
session_start();
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header('location: ?url=index');
    exit;
}
if (is_file("./view/" . $url . ".php")) {
    require_once("./view/" . $url . ".php");
} else {
    echo 'Pagina en construccion';
}
?>