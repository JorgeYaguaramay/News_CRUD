<?php
session_start();
if (is_file("./view/" . $url . ".php")) {
    require_once("./model/" . $url . ".php");
    require_once("./view/" . $url . ".php");
} else {
    echo 'Pagina en construccion';
}
?>