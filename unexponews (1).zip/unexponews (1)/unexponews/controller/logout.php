<?php
session_start();
if (is_file("./model/" . $url . ".php")) {
    require_once("./model/" . $url . ".php");
} else {
    echo 'Pagina en construccion';
}
?>